import 'package:flutter/material.dart';
import 'package:flutter_application_8/screens/homeScreen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 3)).then((value) {
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomeScreen()));
    },);
    return Scaffold(
    
       body: Center(
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Color.fromARGB(255, 147, 213, 188),
                Color.fromARGB(254, 155, 123, 219),
              ],
            )
          ),
          child: Center(
            child: Image.asset("assets/FaaleyatLogo.png",width: 200, height: 200,)
          ),
        ),
      ),
    
    );
  }
}