import 'package:flutter/material.dart';
import 'package:flutter_application_8/components/cardsComp.dart';
import 'package:flutter_application_8/components/searchbarComp.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;
    return  Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromARGB(255, 111, 50, 234),
                  Color.fromARGB(0, 48, 240, 183),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                stops: [0.05, 1.0],
              ),
            ),
            child: Column(
              children: [
                SizedBox(
                  height: screenHeight * 0.02,
                ),
                Text(
                  "Welcome,",
                  style: TextStyle(
                    fontFamily: "font1",
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  "Faaleyat",
                  style: TextStyle(
                    fontSize: screenHeight * 0.04,
                    fontFamily: "font1",
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(
                  height: screenHeight * 0.02,
                ),
                Center(
                  child: searchBar(onSearch: (p0) {}),
                ),
                Container(
                  margin: EdgeInsets.all(screenWidth * 0.03),
                  width: screenWidth * 0.9,
                  height: screenHeight * 0.25,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Column(
                    children: [
                    
                      SizedBox(height: screenHeight * 0.02,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Column(
                            children: [
                              Image.asset(
                                "assets/development.png",
                                height: screenHeight * 0.15,
                                width: screenWidth * 0.15,
                              ),
                              Text(
                                "Event Organizers",
                                style: TextStyle(
                                  fontSize: screenHeight * 0.017,
                                  fontFamily: "font2",
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              Image.asset(
                                "assets/people.png",
                                height: screenHeight * 0.15,
                                width: screenWidth * 0.15,
                              ),
                              Text(
                                "Participants",
                                style: TextStyle(
                                  fontSize: screenHeight * 0.017,
                                  fontFamily: "font2",
                                ),
                              ),
                            ],
                          ),
                          Column(
                            children: [
                              Image.asset(
                                "assets/sponsor.png",
                                height: screenHeight * 0.15,
                                width: screenWidth * 0.15,
                              ),
                              Text(
                                "Sponsors",
                                style: TextStyle(
                                  fontSize: screenHeight * 0.017,
                                  fontFamily: "font2",
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    //Card 1
                    Cards(
                      image: "assets/technical-support.png",
                      detils: "Our Service",
                      onPressed1: (p0) => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const HomeScreen(),
                        ),
                      ),
                    ),

                    //Card 2
                    Cards(
                      image: "assets/event.png",
                      detils: "Events",
                      onPressed1: (p0) => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const HomeScreen(),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenHeight * 0.03,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    //Card 3
                    Cards(
                      image: "assets/customer-service.png",
                      detils: "Contact Us",
                      onPressed1: (p0) => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const HomeScreen(),
                        ),
                      ),
                    ),

                    //Card 4
                    Cards(
                      image: "assets/help.png",
                      detils: "Help & Support",
                      onPressed1: (p0) => Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const HomeScreen(),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: screenHeight * 0.03,
                ),
               
                SizedBox(height: screenHeight * 0.05),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
