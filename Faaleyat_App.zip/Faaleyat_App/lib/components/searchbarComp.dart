import 'package:flutter/material.dart';

class searchBar extends StatelessWidget {
  TextEditingController? SearchController;
  final Function(String) onSearch;

  searchBar({super.key, this.SearchController, required this.onSearch});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.sizeOf(context).width * 0.9,
      child: TextField(
        onChanged: (query) {
          onSearch(query);
        },
        decoration: InputDecoration(
          filled: true,
          fillColor: Colors.white,
          hintText: 'Search',
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.white),
              borderRadius: BorderRadius.circular(15)),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(
                color: Color.fromARGB(255, 207, 197, 210),
              ),
              borderRadius: BorderRadius.circular(15)),
          prefixIcon: Icon(Icons.search),
        ),
      ),
    );
  }
}
