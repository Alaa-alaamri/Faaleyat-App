import 'package:flutter/material.dart';

class Cards extends StatelessWidget {
  Cards({
    required this.onPressed1,
    required this.image,
    required this.detils,
  });

  String? image;
  String? detils;
  final Function(String) onPressed1;

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height;

    double cardWidth =
        screenWidth <= 600 ? screenWidth * 0.4 : screenWidth * 0.45;
    double cardHeight =
        screenWidth <= 600 ? screenHeight * 0.25 : screenHeight * 0.3;
    double imageHeight =
        screenWidth <= 600 ? screenHeight * 0.09 : screenHeight * 0.1;
    double imageWidth =
        screenWidth <= 600 ? screenWidth * 0.8 : screenWidth * 0.55;

    double fontSize =
        screenWidth <= 600 ? screenHeight * 0.02 : screenHeight * 0.04;

    return MaterialButton(
      onPressed: () {
        onPressed1(detils!);
      },
      child: Container(
        width: cardWidth,
        height: cardHeight,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(
          children: [
            SizedBox(
              height: cardHeight * 0.2,
            ),
            Image.asset(
              image!,
              height: imageHeight,
              width: imageWidth,
            ),
            SizedBox(
              height: cardHeight * 0.1,
            ),
            Center(
              child: Text(
                detils!,
                style: TextStyle(
                  fontSize: fontSize,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 1, 1, 1),
                ),
              ),
            ),
            SizedBox(
              height: cardHeight * 0.01,
            ),
          ],
        ),
      ),
    );
  }
}
