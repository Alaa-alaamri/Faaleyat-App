import 'package:flutter/material.dart';
import 'package:flutter_application_8/root/app_root.dart';

void main() {
  runApp(const AppRoot());
}
